package csulb.edu.guessdraw;

import android.graphics.Paint;
import android.graphics.Path;

import java.io.Serializable;

/**
 * Created by Thien on 4/23/2017.
 */

public class PaintObject implements Serializable {
    /*
    private Path drawPath;
    private Paint drawPaint;

    public PaintObject (Path drawPath, Paint drawPaint) {
        this.drawPath = drawPath;
        this.drawPaint = drawPaint;
    }

    public Path getDrawPath ()
    {
        return drawPath;
    }

    public Paint getDrawPaint() {
        return drawPaint;
    }
    */

    private static final long serialVersionUID = 1L;


    float x;
    float y;
    float brush;
    int color;
    int type;
    int width;
    int height;

    public PaintObject(float x, float y, int width, int height, int type, int color, float brush){
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.type = type;
        this.color = color;
        this.brush = brush;
    }
}
